package com.daren.ide;

import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;

public class CodeGenerator {
    
    public static String generate(ViewGroup workspace) {
        StringBuilder code = new StringBuilder();
        code.append("package com.example.generated;\n\n");
        code.append("import android.app.Activity;\n");
        code.append("import android.os.Bundle;\n");
        code.append("import android.widget.*;\n\n");
        code.append("public class MainActivity extends Activity {\n\n");
        code.append("    @Override\n");
        code.append("    protected void onCreate(Bundle savedInstanceState) {\n");
        code.append("        super.onCreate(savedInstanceState);\n");
        code.append("        setContentView(R.layout.activity_main);\n\n");
        
        // Generate code from blocks
        List<Block> blocks = findBlocksInWorkspace(workspace);
        for (Block block : blocks) {
            code.append("        ").append(block.getCode().replace("\n", "\n        ")).append("\n");
        }
        
        code.append("    }\n");
        code.append("}\n");
        
        return code.toString();
    }
    
    private static List<Block> findBlocksInWorkspace(ViewGroup workspace) {
        List<Block> blocks = new ArrayList<>();
        for (int i = 0; i < workspace.getChildCount(); i++) {
            // In a real implementation, we would get the Block object from the view
            // For now, we'll create a simple list of blocks
            Block block = new Block(workspace.getContext(), "Print");
            blocks.add(block);
        }
        return blocks;
    }
}