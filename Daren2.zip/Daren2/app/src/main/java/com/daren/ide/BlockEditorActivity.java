package com.daren.ide;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class BlockEditorActivity extends AppCompatActivity {
    
    private LinearLayout paletteLayout;
    private LinearLayout workspaceLayout;
    private List<Block> blocks = new ArrayList<>();
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_block_editor);
        
        paletteLayout = findViewById(R.id.paletteLayout);
        workspaceLayout = findViewById(R.id.workspaceLayout);
        
        initializeBlocks();
        setupDragAndDrop();
    }
    
    private void initializeBlocks() {
        // Add blocks to palette
        String[] blockTypes = {
            "Variable", "If", "For", "While", "Button", 
            "TextView", "ImageView", "Print", "Function"
        };
        
        for (String type : blockTypes) {
            Block block = new Block(this, type);
            paletteLayout.addView(block.getView());
            blocks.add(block);
        }
    }
    
    private void setupDragAndDrop() {
        workspaceLayout.setOnDragListener(new View.OnDragListener() {
            @Override
            public boolean onDrag(View v, android.view.DragEvent event) {
                switch (event.getAction()) {
                    case android.view.DragEvent.ACTION_DROP:
                        // Handle block drop
                        for (Block block : blocks) {
                            if (block.getView().getTag() != null && 
                                block.getView().getTag().equals("dragging")) {
                                Block newBlock = block.clone();
                                workspaceLayout.addView(newBlock.getView());
                                break;
                            }
                        }
                        break;
                }
                return true;
            }
        });
    }
    
    public void onGenerateCode(View view) {
        String generatedCode = CodeGenerator.generate(workspaceLayout);
        // Show generated code in a dialog or save it
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Generated Code")
               .setMessage(generatedCode)
               .setPositiveButton("OK", null)
               .show();
    }
    
    public void onCompile(View view) {
        String generatedCode = CodeGenerator.generate(workspaceLayout);
        Compiler.compile(this, generatedCode, new Compiler.CompileCallback() {
            @Override
            public void onSuccess(String apkPath) {
                android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(BlockEditorActivity.this);
                builder.setTitle("Success")
                       .setMessage("Project compiled successfully!\nAPK: " + apkPath)
                       .setPositiveButton("OK", null)
                       .show();
            }
            
            @Override
            public void onError(String error) {
                android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(BlockEditorActivity.this);
                builder.setTitle("Compilation Error")
                       .setMessage("Error: " + error)
                       .setPositiveButton("OK", null)
                       .show();
            }
        });
    }
    
    public void onDeepSeekHelp(View view) {
        DeepSeekHelper.askAssistance(this, new DeepSeekHelper.DeepSeekCallback() {
            @Override
            public void onResponse(String response) {
                android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(BlockEditorActivity.this);
                builder.setTitle("DeepSeek Assistance")
                       .setMessage(response)
                       .setPositiveButton("OK", null)
                       .show();
            }
            
            @Override
            public void onError(String error) {
                android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(BlockEditorActivity.this);
                builder.setTitle("DeepSeek Error")
                       .setMessage("Error: " + error)
                       .setPositiveButton("OK", null)
                       .show();
            }
        });
    }
}