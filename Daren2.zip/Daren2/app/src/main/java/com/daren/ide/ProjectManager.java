package com.daren.ide;

import android.content.Context;
import android.content.Intent;
import java.io.File;

public class ProjectManager {
    
    public static void createNewProject(Context context) {
        String projectName = "NewProject_" + System.currentTimeMillis();
        File projectDir = new File(context.getFilesDir(), "projects/" + projectName);
        
        if (!projectDir.exists()) {
            projectDir.mkdirs();
        }
        
        // Start the editor with the new project
        Intent intent = new Intent(context, BlockEditorActivity.class);
        intent.putExtra("projectPath", projectDir.getAbsolutePath());
        context.startActivity(intent);
    }
    
    public static void openProject(Context context) {
        // For simplicity, we'll just create a new project
        // In a real implementation, we would show a dialog to select a project
        createNewProject(context);
    }
}