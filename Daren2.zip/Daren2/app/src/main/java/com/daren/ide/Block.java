package com.daren.ide;

import android.content.Context;
import android.view.View;
import android.widget.TextView;
import org.json.JSONObject;

public class Block {
    private String type;
    private String code;
    private View view;
    private Context context;
    
    public Block(Context context, String type) {
        this.context = context;
        this.type = type;
        this.code = generateCodeTemplate();
        createView();
    }
    
    private void createView() {
        view = new TextView(context);
        ((TextView) view).setText(type);
        view.setBackgroundResource(R.drawable.block_background);
        
        // Make block draggable
        view.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(view);
                view.startDragAndDrop(null, shadowBuilder, null, 0);
                return true;
            }
        });
    }
    
    private String generateCodeTemplate() {
        switch (type) {
            case "Variable":
                return "var %name% = %value%;";
            case "If":
                return "if (%condition%) {\n    %body%\n}";
            case "For":
                return "for (int %index% = 0; %index% < %limit%; %index%++) {\n    %body%\n}";
            case "Button":
                return "Button %name% = findViewById(R.id.%id%);\n%name%.setOnClickListener(v -> {\n    %action%\n});";
            case "Print":
                return "System.out.println(%text%);";
            default:
                return "// Block: " + type;
        }
    }
    
    public View getView() {
        return view;
    }
    
    public String getCode() {
        return code;
    }
    
    public String getType() {
        return type;
    }
    
    public Block clone() {
        return new Block(context, type);
    }
    
    public JSONObject toJson() {
        try {
            JSONObject json = new JSONObject();
            json.put("type", type);
            json.put("code", code);
            return json;
        } catch (Exception e) {
            return null;
        }
    }
    
    public static Block fromJson(Context context, JSONObject json) {
        try {
            String type = json.getString("type");
            return new Block(context, type);
        } catch (Exception e) {
            return null;
        }
    }
}